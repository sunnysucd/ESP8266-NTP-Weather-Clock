#ifndef _ESP8266_HEWEATHER_H_
#define _ESP8266_HEWEATHER_H_

#include "WeatherNow.h"
#include "WeatherForecast.h"
#include "AirQuality.h"
#include "AirQualityForecast.h"
#include "HourlyForecast.h"
#endif